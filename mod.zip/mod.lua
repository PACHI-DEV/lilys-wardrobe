-- This is the Sample Mod!

-- I would recommend keeping your mod_id in a variable to access with create() methods and stuff
-- there's a bunch of methods that prepend your mod_id to the name/oids so it comes in handy!
MOD_NAME = "lilys_wardrobe"

-- store a ref to our book menu for later
MY_BOOK_MENU = nil
MY_BOOK_OBJ = nil

clothing_sprite_id = nil

CLOTHING_IDS = {nil,nil,nil,nil,nil,nil}

-- to match items to their player sprites
CLOTHING_TABLE = {}

-- categorizing clothing items to pull from in sewing
CLOTHING_ITEMS = {
["ANY"] = {},
["dye1"] = {},
["dye2"] = {},
["dye3"] = {},
["dye4"] = {},
["dye5"] = {},
["dye6"] = {},
["dye7"] = {},
["dye8"] = {},
["dye9"] = {},
["dye10"] = {},
["dye11"] = {},
["dye12"] = {},
["dye13"] = {},
["dye14"] = {},
["dye15"] = {},
["dye16"] = {},
["dye17"] = {},
["dye18"] = {}
}

DYE_COLORS = {
["red"] = "dye1",
["blue"] = "dye2",
["yellow"] = "dye3",
["green"] = "dye4",
["orange"] = "dye5",
["purple"] = "dye6",
["black"] = "dye7",
["white"] = "dye8",
["shrouded"] = "dye9",
["sparkling"] = "dye10",
["glowing"] = "dye11",
["gold"] = "dye12",
["turquoise"] = "dye13",
["lime"] = "dye14",
["pink"] = "dye15",
["brown"] = "dye16",
["icy"] = "dye17",
["hallowed"] = "dye18"
}

DYES = {
"dye1",
"dye2",
"dye3",
"dye4",
"dye5",
"dye6",
"dye7",
"dye8",
"dye9",
"dye10",
"dye11",
"dye12",
"dye13",
"dye14",
"dye15",
"dye16",
"dye17",
"dye18" 
}

-- register is called first to register your mod with the game
-- https://wiki.apico.buzz/wiki/Modding_API#register()
function register()
  -- register our mod name, hooks, and local modules
  -- you can see a full list of hooks here:
  -- https://wiki.apico.buzz/wiki/Modding_API#Hooks
  return {
    name = MOD_NAME,
    hooks = {"ready", "pdraw", "tdraw"}, -- subscribe to hooks we want so they're called
    modules = {"define", "scripts", "quests"} -- load other modules we need, in this case "/modules/define.lua" and "/modules/scripts.lua"
  }
end

-- init is called once registered and gives you a chance to run any setup code
-- https://wiki.apico.buzz/wiki/Modding_API#init()
function init() 

  -- turn on devmode
  api_set_devmode(true)

  -- log to the console
  api_log("init", "Hello World!")

  -- here you can define all your stuff!
  -- i recommend you comment all of these out and play with them one by one until you understand how each works
  -- all define scripts are in "/modules/define.lua"

  -- define a new item, in this case an axe
  -- define_item()
  -- define our mod workbench labels (for our item's recipe)
  api_define_workbench("Lily Mod", {
    t1 = "Sample Tab 1",
    t2 = "Sample Tab 2",
    t3 = "Sample Tab 3",
    t4 = "Sample Tab 4",
    t5 = "Sample Tab 5",
  })
  -- define a new object that can be sat on like a bench
  -- define_bench()
  -- -- define a new object that can be slept in like a bed
  -- define_bed()
  -- -- define a new object that will light up like a lantern
  -- define_light()
  -- -- define a new type of wall
  -- define_wall()
  -- -- define a new type of flower
  -- define_flower()
  -- -- define a new type of bee
  -- define_bee()
  -- -- define a new NPC
  -- -- define_npc()
  -- -- define a new menu object, in this case a "recycler" that turns items into seeds 
  -- -- WARNING: advanced
  -- define_recycler()
  api_define_sprite(MOD_NAME .. "_highlight_arrow", "sprites/highlight_arrow.png", 1)
  api_define_sprite(MOD_NAME .. "_sewing_progress", "sprites/sewing machine/sewing_machine_progress.png", 1)
  api_define_sprite(MOD_NAME .. "_silkworm_progress", "sprites/silkworm farm/silkworm_progress.png", 1)
  api_define_sprite(MOD_NAME .. "_silkworm_full", "sprites/silkworm farm/silkworm_farm_full.png", 4)
  api_define_sprite(MOD_NAME .. "_silkworm_empty", "sprites/silkworm farm/silkworm_farm.png", 4)
  
  init_clothing_table()
  
  -- create clothing items list from keys in clothing table
  for k,v in pairs(CLOTHING_TABLE) do
	table.insert(CLOTHING_ITEMS["ANY"], k)
	for k_color,v_color in pairs(DYE_COLORS) do
		if (string.match(k,k_color)) then
			table.insert(CLOTHING_ITEMS[v_color], k)
			api_log("inserted ".. v_color .. " "..k_color .. " " ..k)
		end
	end
  end
  
  define_purple_dress()
  define_purple_bow()
  define_bunny_ears()
  define_green_sprout()
  define_brown_curls()
  
  define_purple_sailor_suit_shirt()
  define_purple_sailor_suit_pants()
  define_purple_sailor_suit_skirt()
  define_green_dress()
  define_white_dress_skirt()
  
  define_diamond_tile()
  define_thread()
  
  define_wardrobe()
  define_sewing_machine()
  define_mannequin()
  define_silkworm_farm()
  
  -- define_npc()
  
  -- this defines a blueprint for every clothing item.
  define_paper()
  define_blueprints()
  define_silk_moth()
  
  -- define a custom command so we can spawn in all our new goodies
  -- "command_treats" is defined in "scripts.lua"
  api_define_command('/treats', "command_treats")
  
  api_define_command('/pos', "log_pos")
  api_define_command('/lily', "spawn_lily")
  
  define_quest0()
  define_quest1()
  define_quest2()
  define_quest3()
  define_quest4()
  define_quest5()
  
  -- if you dont return success here your mod will not load
  -- this can be useful if your define fails as you can decide to NOT return "Success" to tell APICO 
  -- that something went wrong and to ignore your mod
  return "Success"
end

function click()

  -- check not using a net lol
  equipped_item = api_get_equipped()
  highlighted = api_get_highlighted("obj")
  if highlighted ~= nil and equipped_item ~= "net" then

    -- if an obj has a butterfly it has a property called butterfly that you can check
    -- if the value is nil there is currently no butterfly
    -- use this to prevent spawning multiple on the same instance (as a player will only be able to net the first one the rest will get stuck on the obj)
    has_butt = api_gp(highlighted, "butterfly")
    if has_butt == nil then 
      api_create_butterfly("silk_moth", "", highlighted)
    end

  end

end

function tdraw()
	-- draw the backs to the player's clothes
	draw_player_clothes(false)
end

function pdraw()
	-- draw the fronts to the player's clothes
	draw_player_clothes(true)
end

function redraw_player()
	player_pos = api_get_player_position()
	cam_pos = api_get_cam()
	px = player_pos["x"] - 9
	py = player_pos["y"]
	api_gp(api_get_player_instance(),"sprite_index")
	api_draw_sprite(player_sprite, api_gp(api_get_player_instance(),"image_index"), px, py)
end

function draw_player_clothes(is_front)
	-- get position
	player_pos = api_get_player_position()
	cam_pos = api_get_cam()
	px = player_pos["x"] - 9
	py = player_pos["y"]
	player_walking = (api_gp(api_get_player_instance(),"sprite_index") == 376.0)
	
	-- where to start picking frames from
	if is_front then
		draw_frame = 0
	else
		draw_frame = 2
		px = px - cam_pos["x"]
		py = py - cam_pos["y"]
	end
	
	
	for i=0,5,1 do
	  if CLOTHING_IDS[i]~= nil then
		if player_walking then
		  if api_gp(api_get_player_instance(),"dir") == "left" then
			api_draw_sprite_ext(CLOTHING_TABLE[CLOTHING_IDS[i]][draw_frame+1], api_gp(api_get_player_instance(),"image_index"), px + 18, py, -1, 1, 0, nil, 1)
		  else
			api_draw_sprite_ext(CLOTHING_TABLE[CLOTHING_IDS[i]][draw_frame+1], api_gp(api_get_player_instance(),"image_index"), px, py, 1, 1, 0, nil, 1)
		  end
		else
		  if api_gp(api_get_player_instance(),"dir") == "left" then
			api_draw_sprite_ext(CLOTHING_TABLE[CLOTHING_IDS[i]][draw_frame+0], api_gp(api_get_player_instance(),"image_index"), px + 18, py, -1, 1, 0, nil, 1)
			
		  else
			api_draw_sprite_ext(CLOTHING_TABLE[CLOTHING_IDS[i]][draw_frame+0], api_gp(api_get_player_instance(),"image_index"), px, py, 1, 1, 0, nil, 1)
		  end
		end
	  end
	end
end
-- ready is called once all mods are ready and once the world has loaded any undefined instances from mods in the save
-- https://wiki.apico.buzz/wiki/Modding_API#ready()
function ready()
  api_unlock_quest("style_savvy")
  -- api_create_obj("npc421", 3110, 995)
  -- if we haven't already spawned our new npc, spawn them
  -- friend = api_get_menu_objects(nil, "npc69")
  -- if #friend == 0 then
    -- player = api_get_player_position()
    -- api_create_obj("npc69", player["x"] + 16, player["y"] - 32)
  -- end

  -- play a sound to celebrate our mod loading! :D
  api_play_sound("confetti")

end