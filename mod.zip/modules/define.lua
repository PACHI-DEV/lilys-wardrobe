-- all functions in this module will be available to use as long as we specify it in our register() hook


-------------------
--- DEFINE ITEM ---
-------------------

-- define an item and add a recipe for it
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_item()
-- this is a basic item, like a tool, or a resource (log, stick, plank)
function define_item()

  -- define a custom item
  api_define_item({
    id = "cool_axe",
    name = "Cool Axe",
    category = "Decoration",
    tooltip = "This is a cool axe!",
    durability = 1000,
    singular = true
  }, "sprites/item/axe_item.png")

end

function define_paper()
	api_define_item({
	id = "paper",
	name = "Paper",
	category = "Vibing",
	tooltip = "Used to create blueprints in a Sewing Machine",
	singular = false
	}, "sprites/item/paper_item.png")

	-- add the item to the workbench as a recipe
	recipe = {
	{ item = "sawdust1", amount = 5 }
	}
	res = api_define_recipe("t1", MOD_NAME .. "_paper", recipe, 1)
end

function define_blueprints()
  for k,item in pairs(CLOTHING_ITEMS["ANY"]) do
	  def = api_gp(api_get_definition(item),"name")
	  api_define_item({
	  id = "blueprint_"..item,
	  name = ""..def.." Blueprint",
	  category = "Vibing",
	  tooltip = "A blueprint for sewing, requires 2 thread instead of 1. Use it in the Sewing Machine!",
	  singular = true
	  }, "sprites/item/blueprint_item.png")
  end
end

-- function define_blueprint()

  -- api_define_item({
  -- id = "blueprint",
  -- name = "Blueprint",
  -- category = "Vibing",
  -- tooltip = "A blueprint for sewing. Use it in the Sewing Machine!",
  -- singular = true
  -- }, "sprites/item/blueprint_item.png")
  
  -- api_define_item_stats(MOD_NAME .. "_blueprint", { created_item = "" })
  
  -- -- add the item to the workbench as a recipe
  -- recipe = {
  -- { item = "log", amount = 1 }
  -- }
  -- res = api_define_recipe("t1", MOD_NAME .. "_blueprint", recipe, 10)

-- end

function define_brown_curls()
  api_define_object({
    id = 'brown_curls',
    name = 'Lily\'s Hairstyle',
    category = 'Vibing',
    tooltip = 'Microfiber towel, no sulfates, diffuse.',
    has_shadow = false,
	singular = true,
    tools = {'hammer1'},
  }, "sprites/item/brown_curls_item.png", nil)
end

function define_green_sprout()
  api_define_item({
  id = "green_sprout",
  name = "Sprout",
  category = "Vibing",
  tooltip = "It's kind of mushy looking.",
  singular = true
  }, "sprites/item/green_sprout_item.png")
end

function define_purple_sailor_suit_shirt()
  api_define_item({
  id = "purple_sailor_suit_shirt",
  name = "Sailor Shirt",
  category = "Vibing",
  tooltip = "\"I buy sausage\"",
  singular = true
  }, "sprites/item/purple_sailor_suit_shirt_item.png")
end

function define_purple_sailor_suit_pants()
  api_define_item({
  id = "purple_sailor_suit_pants",
  name = "Sailor Pants",
  category = "Vibing",
  tooltip = "\"I buy sausage\"",
  singular = true
  }, "sprites/item/purple_sailor_suit_pants_item.png")
end

function define_purple_sailor_suit_skirt()
  api_define_item({
  id = "purple_sailor_suit_skirt",
  name = "Sailor Skirt",
  category = "Vibing",
  tooltip = "\"I buy sausage\"",
  singular = true
  }, "sprites/item/purple_sailor_suit_skirt_item.png")
end

function define_green_dress()
  api_define_item({
  id = "green_dress",
  name = "Jasmine Dress",
  category = "Vibing",
  tooltip = "Ocha means green tea",
  singular = true
  }, "sprites/item/green_dress_item.png")
end

function define_white_dress_skirt()
  api_define_item({
  id = "white_dress_skirt",
  name = "Dress Skirt",
  category = "Vibing",
  tooltip = "Ocha means green tea",
  singular = true
  }, "sprites/item/white_dress_skirt_item.png")
end

function define_purple_dress()
  api_define_item({
  id = "purple_dress",
  name = "Purple Dress",
  category = "Vibing",
  tooltip = "A pretty purple dress",
  singular = true
  }, "sprites/item/purple_dress_item.png")
end

function define_purple_bow()
  api_define_item({
  id = "purple_bow",
  name = "Purple Bow",
  category = "Vibing",
  tooltip = "A pretty purple bow",
  singular = true
  }, "sprites/item/purple_bow_item.png")

end

function define_bunny_ears()
  api_define_item({
  id = "bunny_ears",
  name = "Bunny Ears",
  category = "Vibing",
  tooltip = "Let's make mochi on the moon!",
  singular = true
  }, "sprites/item/bunny_ears_item.png")

end

function define_thread()
  api_define_item({
  id = "thread",
  name = "Silk Thread",
  category = "Vibing",
  tooltip = "Used at the Sewing Machine to make clothing",
  singular = false
  }, "sprites/item/thread_item.png")

end

function define_diamond_tile()

  -- define an object as normal
  -- but with the "bed" property we can give it bed functionality
  api_define_object({
    id = 'diamond_tile',
    name = 'Diamond Tile',
    category = 'Vibing',
    tooltip = 'Castley',
    has_shadow = false,
    tools = {'hammer1'},
    depth = -8 -- this sets the layering of the player + the object
  }, '/sprites/item/diamond_tile_item.png', nil)

end

------------------
--- DEFINE BED ---
------------------

-- define an object and set it as a "bed"
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_object()
-- objects are items you can place down, but don't have a menu
function define_bed()

  -- define an object as normal
  -- but with the "bed" property we can give it bed functionality
  api_define_object({
    id = 'test_bed',
    name = 'Sample Bed',
    category = 'Vibing',
    tooltip = 'Sleep in me',
    bed = true, -- this allows it to be used as a bed
    has_shadow = true,
    tools = {'hammer1'},
    depth = -8 -- this sets the layering of the player + the object
  }, '/sprites/bed/bed_item.png', nil)

end


--------------------
--- DEFINE BENCH ---
--------------------

-- define an object and set it as a "bench"
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_object()
-- objects are items you can place down, but don't have a menu
function define_bench()

  -- define an object as normal
  -- but with the "bench" property we can give it bench functionality
  api_define_object({
    id = 'test_bench',
    name = 'Sample Bench',
    category = 'Vibing',
    tooltip = 'Sit on me',
    bench = true, -- this allows it to be used as a bench
    has_shadow = true,
    tools = {'hammer1'},
    depth = -8 -- this sets the layering of the player + the object
  }, '/sprites/bench/bench_item.png', nil)

end


--------------------
--- DEFINE LIGHT ---
--------------------

-- define an object and set it as a light source
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_object()
-- objects are items you can place down, but don't have a menu
function define_light()

  -- define an object as normal
  -- but with the "has_lighting" property we can make it light up
  api_define_object({
    id = 'test_light',
    name = 'Sample Light',
    category = 'arm bee aunts',
    tooltip = 'Put me down',
    has_lighting = true,
    has_shadow = true,
    tools = {'hammer1'}
  }, '/sprites/light/light_item.png', nil)

end


-------------------
--- DEFINE WALL ---
-------------------

-- define a new type of wall
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_wall()
-- walls are solid objects that will tile together when placed next to each other
function define_wall()

  -- define an wall as normal
  api_define_wall({
    id = 17,
    name = "Cool Wall" 
  }, "/sprites/wall/wall_sprite.png")

end


---------------------
--- DEFINE FLOWER ---
---------------------

-- define a new type of flower
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_flower()
function define_flower()

  -- create flower_definition table
  flower_def = {
    id = "14",
    species = "my_flower",
    title = "My Flower",
    latin = "Myus Flowerus",
    hint = "Found in deep water",
    desc = "This is my cool ocean flower!",
    aquatic = true,
    variants = 2,
    deep = true,
    smoker = {"stubborn","fiery"},
    recipes = {
      { a = "flower14", b = "flower1", s = "flower6" }
    }
  }
  
  -- define flower
  api_define_flower(flower_def, 
    "sprites/flower/flower_item.png", "sprites/flower/flower_variants.png", 
    "sprites/flower/flower_seed_item.png", "sprites/flower/flower_hd.png",
    {r=100, g=100, b=100}
  );

end


------------------
--- DEFINE BEE ---
------------------

-- define a new bee and a new bee "trait"
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_bee()
-- once created you can spawn the bee with /gimme bee.{id} or use api_give_item(bee:{id}, 1)
function define_bee()

  -- setup bee_definition 
  bee_def = {
    id = "nightcrawler",
    title = "Nightcrawler",
    latin = "Crawly Nighty",
    hint = "Found on only the darkest of nights",
    desc = "This is just a cool damn bee",
    lifespan = {"Normal"},
    productivity = {"Normal", "Fast"},
    fertility = {"Fecund", "Prolific"},
    stability = {"Normal", "Stable"},
    behaviour = {"Nocturnal"},
    climate = {"Temperate"},
    rainlover = false,
    snowlover = false,
    grumpy = true,
    produce = "log",
    recipes = {
      { a = "nightcrawler", b = "dream", s = "chaotic" }
    },
    calming = {"flower10", "flower11"},
    chance = 100,
    bid = "X3",
    requirement = ""
  }

  -- create new bee
  -- in this example we have a "sprites" folder in our mod root
  api_define_bee(bee_def, 
    "sprites/bee/bee_item.png", "sprites/bee/bee_shiny.png", 
    "sprites/bee/bee_hd.png",
    {r=100, g=100, b=100},
    "sprites/bee/bee_mag.png",
    "My Magazine Headline!",
    "My magazine body text!"
  );

  -- add a new mutation for our new bee
  -- this will appear on the dream + rocky bee pages (if there's room)
  -- "mutation_chance" is a script defined in "scripts.lua"
  api_define_bee_recipe("dream", "rocky", "nightcrawler", "mutation_chance")

  -- add a new bee trait including our newly defined bee
  -- this trait will be added to all bees using the defaults set below
  -- you can then do whatever you like with this trait when you access it through a slot/item stats prop
  api_define_trait("magic", {
    common = {"low"}, 
    dream  = {"low", "medium"}, 
    nightcrawler = {"high"}
  }, {"none"}) -- default for all the other bees

end

function define_wardrobe()

  -- define new menu object as normal
  api_define_menu_object({
    id = "wardrobe",
    name = "Wardrobe",
    category = "Storage",
    tooltip = "Lets you equip clothing and gear!",
    layout = {
      {9, 19},
      {9, 41},
	  {9, 63},
	  {32, 19},
      {32, 41},
	  {32, 63},
	  {74, 19},
      {74, 41},
	  {74, 63},
	  {97, 19},
      {97, 41},
	  {97, 63},
	  {120, 19},
      {120, 41},
	  {120, 63},
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Equipment", "RED"},
      {"2. Extra Storage", "GREEN"},
    },
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/wardrobe/wardrobe_item.png", "sprites/wardrobe/wardrobe_menu.png", {
    define = "wardrobe_define" -- defined in "scripts.lua" as a function
  })
  
  -- add the item to the workbench as a recipe
  recipe = {
  { item = "log", amount = 20 },
  { item = "planks1", amount = 10 }
  }
  res = api_define_recipe("t1", MOD_NAME .. "_wardrobe", recipe, 1)
end

function define_mannequin()

  -- define new menu object as normal
  api_define_menu_object({
    id = "mannequin",
    name = "Mannequin",
    category = "Decoration",
    tooltip = "Lets you display clothing and gear!",
    layout = {
      {9, 19},
      {9, 41},
	  {9, 63},
	  {32, 19},
      {32, 41},
	  {32, 63}
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Equipment", "RED"},
      {"2. Extra Storage", "GREEN"},
    },
	item_sprite = "sprites/mannequin/mannequin_item.png",
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/mannequin/mannequin_model.png", "sprites/mannequin/mannequin_menu.png", {
	define = "mannequin_define", -- defined in "scripts.lua" as a function
  },
  "mannequin_object_draw")
  
  -- add the item to the workbench as a recipe
  recipe = {
  { item = "log", amount = 10 },
  { item = "planks1", amount = 5 },
  { item = "sticks1", amount = 1 }
  }
  res = api_define_recipe("t1", MOD_NAME .. "_mannequin", recipe, 1)

end

function define_white_mannequin()

  -- define new menu object as normal
  api_define_menu_object({
    id = "white_mannequin",
    name = "White Mannequin",
    category = "Decoration",
    tooltip = "Lets you display clothing and gear! Painted White.",
    layout = {
      {9, 19},
      {9, 41},
	  {9, 63},
	  {32, 19},
      {32, 41},
	  {32, 63}
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Equipment", "RED"},
      {"2. Extra Storage", "GREEN"},
    },
	item_sprite = "sprites/mannequin/mannequin_item.png",
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/mannequin/mannequin_model.png", "sprites/mannequin/mannequin_menu.png", {
	define = "mannequin_define", -- defined in "scripts.lua" as a function
  },
  "mannequin_object_draw")
  
  -- add the item to the workbench as a recipe
  recipe = {
  { item = "log", amount = 10 },
  { item = "planks1", amount = 5 },
  { item = "sticks1", amount = 1 }
  }
  res = api_define_recipe("t1", MOD_NAME .. "_mannequin", recipe, 1)

end

function define_sewing_machine()
  -- define new menu object as normal
  api_define_menu_object({
    id = "sewing_machine",
    name = "Sewing Machine",
    category = "Crafting",
    tooltip = "Lets you sew clothing!",
    layout = {
      {7, 17, "Input", {"customX:"..MOD_NAME.."_blueprint"}},
      {7, 39, "Input", {MOD_NAME.."_thread"}},
	  {30, 17, "Input", {"customX:dye"}},
      {30, 39, "Input", {MOD_NAME.."_paper"}},
	  {99, 17, "Output"},
      {99, 40, "Output"},
	  {122, 17, "Output"},
      {122, 40, "Output"},
	  {7, 66},
	  {30, 66},
	  {53, 66},
	  {76, 66},
	  {99, 66},
	  {122, 66}
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Sewing Input", "GREEN"},
      {"2. Sewn Output", "RED"},
      {"3. Extra Storage", "WHITE"},
    },
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/sewing machine/sewing_machine_item.png", "sprites/sewing machine/sewing_machine_menu.png", {
    define = "sewing_machine_define", -- defined in "scripts.lua" as a function
	draw = "sewing_machine_draw" -- defined in "scripts.lua" as a function
  })
  
  api_define_validation_icon("customX:"..MOD_NAME.."_blueprint", "sprites/validation/blueprint.png")
  api_define_validation_icon("customX:dye", "sprites/validation/dye.png")
  
  -- add the item to the workbench as a recipe
  recipe = {
  { item = "stone", amount = 30 }
  }
  res = api_define_recipe("t1", MOD_NAME .. "_sewing_machine", recipe, 1)
end

function define_silkworm_farm()
  -- define new menu object as normal
  api_define_menu_object({
    id = "silkworm_farm",
    name = "Silkworm Farm",
    category = "Habitats",
    tooltip = "Put silkworms here to get silk threads",
    layout = {
      {9, 19, "Input", {"customX:caterpiller"}},
      {9, 41, "Input", {"customX:caterpiller"}},
	  {9, 63, "Input", {"customX:caterpiller"}},
	  {32, 19, "Input", {"customX:caterpiller"}},
      {32, 41, "Input", {"customX:caterpiller"}},
	  {32, 63, "Input", {"customX:caterpiller"}},
	  {96, 19, "Output"},
      {96, 41, "Output"},
	  {96, 63, "Output"},
	  {119, 19, "Output"},
      {119, 41, "Output"},
	  {119, 63, "Output"},
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Sewing Input", "GREEN"},
      {"2. Sewn Output", "RED"},
      {"3. Extra Storage", "WHITE"},
    },
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/silkworm farm/silkworm_farm.png", "sprites/silkworm farm/silkworm_farm_menu.png", {
    define = "silkworm_farm_define", -- defined in "scripts.lua" as a function
	change = "silkworm_farm_change",
	tick = "silkworm_farm_tick",
	draw = "silkworm_farm_draw" -- defined in "scripts.lua" as a function
  },
  "silkworm_farm_object_draw")
  
  api_define_validation_icon("customX:caterpiller", "sprites/validation/silk_worm.png")
  
  -- add the item to the workbench as a recipe
  recipe = {
  { item = "planks1", amount = 10 }
  }
  res = api_define_recipe("t1", MOD_NAME .. "_silkworm_farm", recipe, 1)
end

-----------------------
--- DEFINE RECYCLER ---
-----------------------

-- define a menu object, in this case a "recycler" machine
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_menu_object()
-- menu objects are items you can place down and then click on to open an actual menu
function define_recycler()

  -- define new menu object as normal
  api_define_menu_object({
    id = "recycle_bin",
    name = "Recycle Bin",
    category = "Tools",
    tooltip = "Let's you recycle items into random flower seeds",
    layout = {
      {7, 17},
      {7, 39},
      {30, 17},
      {30, 39},
      {99, 17, "Output"},
      {99, 39, "Output"},
      {122, 17, "Output"},
      {122, 39, "Output"},
      {7, 66},
      {30, 66},
      {53, 66},
      {76, 66},
      {99, 66},
      {122, 66},
    },
    buttons = {"Help", "Target", "Close"},
    info = {
      {"1. Recycle Input", "GREEN"},
      {"2. Recycled Output", "RED"},
      {"3. Extra Storage", "WHITE"},
    },
    tools = {"mouse1", "hammer1"},
    placeable = true
  }, "sprites/recycler/recycler_item.png", "sprites/recycler/recycler_menu.png", {
    define = "recycler_define", -- defined in "scripts.lua" as a function
    draw = "recycler_draw", -- defined in "scripts.lua" as a function
    tick = "recycler_tick", -- defined in "scripts.lua" as a function
    change = "recycler_change" -- defined in "scripts.lua" as a function
  })

end


------------------
--- DEFINE NPC ---
------------------

-- define a new npc
-- https://wiki.apico.buzz/wiki/Modding_API#api_define_npc()
-- an npc is a special type of menu object that has a dialogue window + a shop menu
function define_npc()
	
  lily_dialogue = {}
  lily_dialogue["A"] = {
    P = "I am a prompt for dialogue A!",
    D = {
      "You should check out my other project: my game RhythmMMO!",
      "All NPCs need at least a dialogue A or they break",
      "This is a chance for you to introduce an NPC",
      "Goodbye!"
    },
    A = {
      "$action01",
      "$action01",
      "$action01",
      "$action49"
    }
  }
  lily_dialogue["B"] = {
    P = "I am a new prompt for dialogue B!",
    D = {
      "Well done on getting a glossy pearl!"
    },
    A = {
      "$action49"
    }
  }
  
  --set npc definition
  npc_def = {
    id = 421,
    name = "Lily",
    pronouns = "She/Her",
    tooltip = "Her arms are missing!",
    shop = true,
    walking = true,
    stock = {MOD_NAME.."_thread",MOD_NAME.."_paper"}, -- max 10
    specials = {MOD_NAME.."_sewing_machine", MOD_NAME.."_mannequin", MOD_NAME.."_wardrobe"}, -- must be 3
    dialogue = lily_dialogue,
    greeting = "Hi, I'm Lily - or PACHI_DEV! Depends on who you ask."
  }

  -- define npc
  api_define_npc2(npc_def,
    "sprites/lily_npc/npc_standing.png",
    "sprites/lily_npc/npc_standing_h.png",
    "sprites/lily_npc/npc_walking.png",
    "sprites/lily_npc/npc_walking_h.png",
    "sprites/lily_npc/npc_head.png",
    "sprites/lily_npc/npc_bust.png",
    "sprites/lily_npc/npc_item.png",
    "sprites/lily_npc/npc_dialogue_menu.png",
    "sprites/lily_npc/npc_shop_menu.png",
	"lily_dialogue_check"
  )

end

function lily_dialogue_check()
	return {'A'}
end

function define_silk_moth()
	-- set up our butterfly definition 
	butt_def = {
	  id = "silk_moth",
	  title = "Silk Moth",
	  latin = "Bombyx mandarina",
	  hint = "Really likes green flowers but during a wet dawn!",
	  desc = "Its silk worms produce silk thread!",
	  biome = "forest",
	  lifespan = 120,
	  behaviour = "Nocturnal",
	  climate = "Any",
	  rainlover = false,
	  snowlover = false,
	  flora = "flora2",
	  flowers = {"flower8", "flower16", "flower3"},
	  chance = 50,
	  named = true
	}

	-- actually define the butterfly 
	api_define_butterfly(butt_def, 
	  "sprites/silk moth/silk_moth_item.png", "sprites/silk moth/silk_moth_golden_item.png", 
	  "sprites/silk moth/silk_worm.png",
	  "sprites/silk moth/silk_moth_hd.png",
	  {r=100, g=100, b=100}
	);
end