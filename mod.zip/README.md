# lilys-wardrobe
This is my clothing mod! In it you can:

+ sew clothes && accessories
+ farm silkworms and silkmoths to collect thread
+ submit custom clothing @ https://github.com/PACHI-DEV/lilys-wardrobe/issues OR lily#3139 on Discord.

Thank you and enjoy!

- lily @ PACHI_DEV
