function define_quest0()
	-- create quest definition
	quest_def = {
	  id = "style_savvy",
	  title = "Style Savvy",
	  reqs = {MOD_NAME.."_mannequin@1"},
	  icon = MOD_NAME.."_mannequin",
	  reward = MOD_NAME.."_bunny_ears@1",
	  unlock = {"sew_whats_next"}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "Welcome to Lily's Wardrobe!" , color = "FONT_GREEN" },
	  { text = "" },
	  { text = "This is a mod where you can create clothing and gear to express yourself."},
	  { text = "" },
	  { text = "Let's get started!"}
	}
	quest_page2 = {
	  { text = "Mannequins can display clothing you create - just put the items in its inventory and the outfit will display." },
	  { text = "" },
	  { text = "Create a Mannequin at your Mod Workbench - if you do, I'll give you a starter gift for you to try out." },
	  { text = "" },
	  { text = "Create 1 Mannequin to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
	
end

function define_quest1()
	-- create quest definition
	quest_def = {
	  id = "sew_whats_next",
	  title = "Sew What's Next",
	  reqs = {MOD_NAME.."_sewing_machine@1"},
	  icon = MOD_NAME.."_sewing_machine",
	  reward = MOD_NAME.."_thread@5",
	  unlock = {"sericultural_icon"}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "Good job with the bunny mannequin!", color = "FONT_GREEN"},
	  { text = "" },
	  { text = "Let's collect more clothing items to display. To do that, you'll need a Sewing Machine."},
	  { text = "" },
	  { text = "Once you create a Sewing Machine, you can craft random clothing items by inserting thread and clicking the circles."}
	}
	quest_page2 = {
	  { text = "Sewing Machines can be crafted at the Mod Workbench."},
	  { text = "" },
	  { text = "Create 1 Sewing Machine to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
	
end

function define_quest2()
	-- create quest definition
	quest_def = {
	  id = "sericultural_icon",
	  title = "Sericultural Icon",
	  reqs = {MOD_NAME.."_silkworm_farm@1"},
	  icon = MOD_NAME.."_silkworm_farm",
	  reward = MOD_NAME.."_silkworm_farm@2",
	  unlock = {"multithreading"}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "You're doing sew good!" , color = "FONT_GREEN" },
	  { text = "" },
	  { text = "You may notice you've received some thread. You can use it to create random clothing items at the sewing machine. Eventually, though, you'll run out of that thread and need more."},
	  { text = "" },
	  { text = "So, let's get more!"}
	}
	quest_page2 = {
	  { text = "To get thread you'll need to farm it. Thread can be harvested from silkworms using a Silkworm Farm. Silkworm Farms can be crafted at the Mod Workbench."},
	  { text = ""},
	  { text = "If you find a Silk Moth, you can grow silkworms in the Butterfly hotel. Keep in mind that they are nocturnal!"},
	  { text = ""},
	  { text = "Craft 1 Silkworm Farm to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
end

function define_quest3()
	-- create quest definition
	quest_def = {
	  id = "multithreading",
	  title = "Multithreading",
	  reqs = {MOD_NAME.."_thread@10"},
	  icon = "caterpiller:silk_worm",
	  reward = MOD_NAME.."_thread@10",
	  unlock = {"fabric_ation"}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "You're doing sew good!" , color = "FONT_GREEN" },
	  { text = "" },
	  { text = "You may notice you've received some thread. You can use it to create random clothing items at the sewing machine. Eventually, though, you'll run out of that thread and need more."},
	  { text = "" },
	  { text = "So, let's get more!"}
	}
	quest_page2 = {
	  { text = "To get thread you'll need to farm it. Thread can be harvested from silkworms using a Silkworm Farm."},
	  { text = ""},
	  { text = "If you find a Silk Moth, you can put them in the Butterfly Hotel to get silkworms. Keep in mind that they are nocturnal! Once you get silkworms, put them in the Silkworm Farm and wait. They will continue to produce thread until their life runs out."},
	  { text = ""},
	  { text = "Retrieve 10 Silk Thread to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
end

function define_quest4()
	-- create quest definition
	quest_def = {
	  id = "fabric_ation",
	  title = "Fabric-ation",
	  reqs = {MOD_NAME.."_purple_bow@1",MOD_NAME.."_blueprint_"..MOD_NAME.."_purple_bow@1"},
	  icon = "dye6",
	  reward = MOD_NAME.."_blueprint_"..MOD_NAME.."_purple_dress@1",
	  unlock = {"the_lion_the_witch_and_the_wardrobe"}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "Textile-ent work!" , color = "FONT_GREEN" },
	  { text = "" },
	  { text = "Now that you have lots of thread, you can make lots of random clothing! If you're looking for a specific item, you can include a dye in the color of that item to narrow it down to just items in that color."},
	  { text = "" },
	  { text = "When you're inventing new items, you can choose to make a Blueprint. Blueprints allow you to craft a specific item over and over again."}
	}
	quest_page2 = {
	  { text = "Try creating a Purple Bow and a Blueprint for it."},
	  { text = ""},
	  { text = "To do that, insert Thread, Purple Dye and Paper into the Sewing Machine and click the circles. Including Paper will allow you to make a Blueprint for the item you create along with the item. Paper can be crafted at the Mod Workbench."},
	  { text = ""},
	  { text = "Create 1 Purple Bow and 1 Purple Bow Blueprint to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
end

function define_quest5()
	-- create quest definition
	quest_def = {
	  id = "the_lion_the_witch_and_the_wardrobe",
	  title = "The Lion, the Witch and the Wardrobe",
	  reqs = {MOD_NAME.."_wardrobe@1"},
	  icon = MOD_NAME.."_wardrobe",
	  reward = MOD_NAME.."_wardrobe@1",
	  unlock = {}
	}

	-- create quest pages 
	quest_page1 = {
	  { text = "You're an Icon!" , color = "FONT_GREEN" },
	  { text = "" },
	  { text = "Now you may ask: How do I actually wear these clothing items? The answer is simple - with a Wardrobe of course!"},
	  { text = "" },
	  { text = "To put on clothes, open the Wardrobe and insert items into the star slots. Then click the \"plus\" button."}
	}
	quest_page2 = {
	  { text = "Try creating a Wardrobe. Have fun accessorizing!"},
	  { text = ""},
	  { text = "Tip: You can create multiple Wardrobes and use them to store different outfits. Then you can swap them out whenever you want!"},
	  { text = ""},
	  { text = "Craft 1 Wardrobe to continue.", color = "FONT_RED"}
	}

	-- define quest
	api_define_quest(quest_def, quest_page1, quest_page2)
end