-- all functions in this module will be available to use as long as we specify it in our register() hook


-----------------------
--- GENERAL SCRIPTS ---
-----------------------

function command_treats(args)

  -- items, objects, and menu objects use your MOD_NAME in their oid
  api_give_item(MOD_NAME .. "_purple_dress", 1)
  api_give_item(MOD_NAME .. "_purple_bow", 1)
  api_give_item(MOD_NAME .. "_bunny_ears", 1)
  api_give_item(MOD_NAME .. "_wardrobe", 1)
  api_give_item(MOD_NAME .. "_sewing_machine", 1)
  api_give_item(MOD_NAME .. "_thread", 3)
  api_give_item(MOD_NAME .. "_mannequin", 2)
  
  api_give_money(100)

  -- flowers, bees, walls and NPCs DO NOT use your MOD_NAME in their oid!
  -- api_give_item("wall17", 1)
  -- api_give_item("flower14", 1)
  -- api_give_item("bee:nightcrawler", 1)
  -- api_give_item("npc69", 1)

end

function log_pos()
	-- get position of the player
	player_pos = api_get_player_position()
	
	api_log("player position:\n x_"..player_pos["x"].." y_"..player_pos["y"])
end

function spawn_lily()
	-- get position of the player
	player_pos = api_get_player_position()
	
	-- create object
	api_create_obj(MOD_NAME.."_lily_npc", player_pos["x"], player_pos["y"])
end

------------------------
--- RECYCLER SCRIPTS ---
------------------------

-- the define script is called when a menu object instance is created
-- this means we can define properties on the menu object for the first time
function recycler_define(menu_id)

  -- create initial props
  api_dp(menu_id, "working", false)
  api_dp(menu_id, "p_start", 0)
  api_dp(menu_id, "p_end", 1)

  -- create gui for the menu
  api_define_gui(menu_id, "progress_bar", 49, 20, "recycler_gui_tooltip", "sprites/recycler/recycler_gui_arrow.png")
  
  -- save gui sprite ref for later
  spr = api_get_sprite("sp_sample_mod_progress_bar")
  api_dp(menu_id, "progress_bar_sprite", spr)

  -- add our p_start and p_end props to the default _fields list so the progress is saved 
  -- any keys in _fields will get their value saved when the game saves, and loaded when the game loads again
  fields = {"p_start", "p_end"}
  fields = api_sp(menu_id, "_fields", fields)

end

-- the change script lets us listen for a change in the menu's slots
-- it's called when a slot changes in the menu
function recycler_change(menu_id)

  -- if we have items in the first four slots let's get to work
  input_slot = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4}, true)
  if input_slot ~= nil then 
    api_sp(menu_id, "working", true)
  else
    api_sp(menu_id, "working", false)
  end

end

-- the tick script lets us run logic we need for the menu object 
-- it's called every 0.1s (real-time)
function recycler_tick(menu_id)

  -- handle countdown if working
  if api_gp(menu_id, "working") == true then
    -- add to counter
    api_sp(menu_id, "p_start", api_gp(menu_id, "p_start") + 0.1)
    -- if we hit the end, i.e. 10s have passed
    if api_gp(menu_id, "p_start") >= api_gp(menu_id, "p_end") then

      -- reset the counter
      api_sp(menu_id, "p_start", 0)
      
      -- get the "input" slots to get an item
      input_slot = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4}, true)
      -- assuming there is a slot width stuff
      if input_slot ~= nil then

        -- remove 1 from slot
        api_slot_decr(input_slot["id"])

        -- add seed to output
        seed_item = api_choose({"seed1", "seed2", "seed3"})
        output_slot = api_slot_match_range(menu_id, {"", seed_item}, {5, 6, 7, 8}, true)
        if output_slot ~= nil then
          -- if empty slot add 1 seed item
          if output_slot["item"] == "" then
            api_slot_set(output_slot["id"], seed_item, 1)
          -- otherwise add to existing seed item in slot
          else 
            api_slot_incr(output_slot["id"])
          end
        end

        -- recheck input, if nothing then stop working
        input_slot = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4}, true)
        if input_slot == nil then api_sp(menu_id, "working", false) end

      end
    end
  end
end

-- the draw script lets us draw custom things on the menu when it's open
-- here we can draw GUI elements or buttons or other things
-- you should avoid putting complex logic in the draw script
function recycler_draw(menu_id)
  -- get camera
  cam = api_get_cam()

  -- draw gui progress here
  gui = api_get_inst(api_gp(menu_id, "progress_bar"))
  spr = api_gp(menu_id, "progress_bar_sprite")

  -- draw arrow "progress" block then cover up with arrow hole
  -- arrow sprite is 47x10
  gx = gui["x"] - cam["x"]
  gy = gui["y"] - cam["y"]
  progress = (api_gp(menu_id, "p_start") / api_gp(menu_id, "p_end") * 47)
  api_draw_sprite_part(spr, 2, 0, 0, progress, 10, gx, gy)
  api_draw_sprite(spr, 1, gx, gy)

  -- draw highlight if highlighted
  if api_get_highlighted("ui") == gui["id"] then
    api_draw_sprite(spr, 0, gx, gy)
  end
end

-- return text for gui tooltip
-- this method is called by the GUI instance when we hover over it
-- the text returned is shown in a tooltip
function recycler_gui_tooltip(menu_id) 
  progress = math.floor((api_gp(menu_id, "p_start") / api_gp(menu_id, "p_end")) * 100)
  percent = tostring(progress) .. "%"
  return {
    {"Progress", "FONT_WHITE"},
    {percent, "FONT_BGREY"}
  }
end

------------------------
--- WARDROBE SCRIPTS ---
------------------------

function wardrobe_define(menu_id)

  -- create initial props
  -- api_dp(menu_id, "working", false)
  -- api_dp(menu_id, "p_start", 0)
  -- api_dp(menu_id, "p_end", 1)

  -- create gui for the menu
  api_define_button(menu_id, "test_button", 58, 46, "", "wardrobe_load", "sprites/wardrobe/wardrobe_button.png")

end

function wardrobe_load(menu_id)
	input_slots = api_slot_match_range(menu_id, {"ANY"}, {1,2,3,4,5,6}, false)
	if input_slots ~= nil then 
		for i=1,#input_slots,1 do
			slot_index = api_gp(input_slots[i],"index")
			api_log("slot " .. (slot_index) .. " " .. api_get_slot(menu_id, slot_index)["item"])
			-- set global value to slot value
			CLOTHING_IDS[slot_index - 1]=api_get_slot(menu_id, slot_index)["item"]
			-- api_log("player_first_slot", CLOTHING_IDS[slot_index - 1])
		end
	end

	--remove empties
	input_slots = api_slot_match_range(menu_id, {""}, {1,2,3,4,5,6}, false)
	if input_slots ~= nil then 
		-- compare all slots to ids to check for discrepancies
		for i=1,#input_slots,1 do
			slot_index = api_gp(input_slots[i],"index")
			api_log("slot " .. (slot_index) .. " " .. api_get_slot(menu_id, slot_index)["item"])
			-- set global value to slot value
			CLOTHING_IDS[slot_index - 1]= nil
			-- api_log("player_first_slot", CLOTHING_IDS[slot_index - 1])
		end
	end
	
	api_play_sound("pop")
end

-- the change script lets us listen for a change in the menu's slots
-- it's called when a slot changes in the menu
function wardrobe_change(menu_id)
  
end

------------------------
--- SEWING SCRIPTS ---
------------------------

function sewing_machine_define(menu_id)

  -- create initial props
  -- api_dp(menu_id, "working", false)
  -- api_dp(menu_id, "p_start", 0)
  -- api_dp(menu_id, "p_end", 1)
  
  -- create gui for the menu
  api_define_button(menu_id, "test_button_0", 55+(0*6), 38, "", "progress_sewing_0", "sprites/sewing machine/sewing_machine_button.png")
  api_define_button(menu_id, "test_button_1", 55+(1*6), 38, "", "progress_sewing_1", "sprites/sewing machine/sewing_machine_button.png")
  api_define_button(menu_id, "test_button_2", 55+(2*6), 38, "", "progress_sewing_2", "sprites/sewing machine/sewing_machine_button.png")
  api_define_button(menu_id, "test_button_3", 55+(3*6), 38, "", "progress_sewing_3", "sprites/sewing machine/sewing_machine_button.png")
  api_define_button(menu_id, "test_button_4", 55+(4*6), 38, "", "progress_sewing_4", "sprites/sewing machine/sewing_machine_button.png")
  api_define_button(menu_id, "test_button_5", 55+(5*6), 38, "", "progress_sewing_5", "sprites/sewing machine/sewing_machine_button.png")
  
  -- properties
  api_dp(menu_id, "working", false)
  api_dp(menu_id, "progress", 0)
  api_dp(menu_id, "p_end", 1)
  api_dp(menu_id, "which_button", 0)
end

function progress_sewing(menu_id, which)
	if (api_gp(menu_id, "which_button") == which and api_slot_match_range(menu_id, {MOD_NAME .. "_thread"}, {1,2,3,4}, true) ~= null) then
		api_sp(menu_id, "progress", api_gp(menu_id, "progress")+1)
		-- api_log("increased progress")
		api_play_sound("rollover")
		
		picked_button = api_gp(menu_id, "which_button")
		while(picked_button == api_gp(menu_id, "which_button"))
		do
		   picked_button = api_random_range(0, 5)
		end
		api_sp(menu_id, "which_button", picked_button)
		
		if (api_gp(menu_id, "progress")>9) then
			api_sp(menu_id, "progress", 0)
			create_clothing(menu_id)
		end
	end
end

function create_clothing(menu_id)
	input_slot = api_slot_match_range(menu_id, {"ANY"}, {2}, true)
	dye_slot = api_slot_match_range(menu_id, {"ANY"}, {3}, true)
	blueprint_slot = api_slot_match_range(menu_id, {"ANY"}, {1}, true) --set to any since we limited it to blueprints in the define
	paper_slot = api_slot_match_range(menu_id, {"ANY"}, {4}, true)
	output_slots = api_slot_match_range(menu_id, {""}, {5,6,7,8}, false) -- set to false as we need two output slots open
	-- api_log("found dye " .. dye_slot)
	
	if input_slot ~= nil and #output_slots>0 then
		if (blueprint_slot == nil) then
			api_slot_decr(api_gp(input_slot, "id"))
			if (dye_slot ~= nil and #CLOTHING_ITEMS[api_gp(dye_slot, "item")] > 0) then
				api_log("found dye " .. api_gp(dye_slot, "item"))
				chosen_item = api_choose(CLOTHING_ITEMS[api_gp(dye_slot, "item")])
				api_slot_set(api_gp(output_slots[1], "id"),chosen_item, 1)
				if (#output_slots > 1 and paper_slot~=nil) then
					api_log("found.. " .. MOD_NAME.."_blueprint_"..chosen_item)
					api_slot_set(api_gp(output_slots[2], "id"), MOD_NAME.."_blueprint_"..chosen_item, 1)
					api_slot_decr(paper_slot["id"])
				end
				-- api_log("made.. ",dye_slot["item"])
				api_slot_decr(dye_slot["id"])
				api_play_sound("pop")
			else
				chosen_item = api_choose(CLOTHING_ITEMS["ANY"])
				api_slot_set(api_gp(output_slots[1], "id"), chosen_item, 1)
				if (#output_slots > 1 and paper_slot~=nil) then
					api_log("found.. " .. MOD_NAME.."_blueprint_"..chosen_item)
					api_slot_set(api_gp(output_slots[2], "id"), MOD_NAME.."_blueprint_"..chosen_item, 1)
					api_slot_decr(paper_slot["id"])
				end
				api_play_sound("pop")
			end
		elseif input_slot["count"]>1 then
			api_log("caught!")
			slot = blueprint_slot["item"]
			api_log(string.sub(api_gp(blueprint_slot, "item"),#(MOD_NAME.."_blueprint_")+1,#slot))
			api_slot_set(api_gp(output_slots[1], "id"), string.sub(api_gp(blueprint_slot, "item"),#(MOD_NAME.."_blueprint_")+1,#slot), 1)
			api_slot_decr(input_slot["id"])
			api_slot_decr(input_slot["id"])
			api_play_sound("pop")
		else
			api_log("not caught")
		end

	end
end

function progress_sewing_0(menu_id)
	progress_sewing(menu_id,0)
end
function progress_sewing_1(menu_id)
	progress_sewing(menu_id,1)
end
function progress_sewing_2(menu_id)
	progress_sewing(menu_id,2)
end
function progress_sewing_3(menu_id)
	progress_sewing(menu_id,3)
end
function progress_sewing_4(menu_id)
	progress_sewing(menu_id,4)
end
function progress_sewing_5(menu_id)
	progress_sewing(menu_id,5)
end

function sewing_machine_draw(menu_id)
  if (api_slot_match_range(menu_id, {MOD_NAME .. "_thread"}, {2,4}, true) ~= nil) then
	  cam = api_get_cam()
	  api_draw_button(api_gp(menu_id, "test_button_" .. math.floor(api_gp(menu_id, "which_button")//1)), true)
	  api_draw_sprite_part(api_get_sprite("sp_"..MOD_NAME.."_sewing_progress"), 0, 0, 0, (api_gp(menu_id, "progress")*3.6)//1, 4, api_gp(menu_id,"x") - cam["x"] + 55, api_gp(menu_id,"y") - cam["y"] + 29)
  end
end

-------------------
--- MANNEQUIN SCRIPTS ---
-------------------
function mannequin_define(menu_id)
  -- properties
end

function mannequin_object_draw(display)
	highlighted = api_get_highlighted("menu_obj")
	-- api_log("highlighted ".. highlighted)
	-- api_log("this ".. display)
	cur_frame = 0
	if (highlighted ~= nil) then
		if (highlighted == display) then
			cur_frame = 1
		else
			cur_frame = 0
		end
	else
		cur_frame = 0
	end
	
	slots = api_get_slots(api_gp(display, "menu"))
	if (cur_frame == 1) then
		for a=1,6,1 do 
		  if (slots[a]["item"] ~= "") then
			api_draw_sprite_ext(CLOTHING_TABLE[slots[a]["item"]][2], 0, api_gp(display,"x")-1, api_gp(display,"y")-3, 1, 1, 0, nil, 1)
		  end
		end
		api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_highlight_arrow"), 0, api_gp(display,"x")+4, api_gp(display,"y")-7, 1, 1, 0, nil, 1)
	end
	api_draw_sprite_ext(api_gp(display, "sprite_index"), cur_frame, api_gp(display,"x"), api_gp(display,"y"), 1, 1, 0, nil, 1)
	for b=1,6,1 do 
	  if (slots[b]["item"] ~= "") then
		api_draw_sprite_ext(CLOTHING_TABLE[slots[b]["item"]][0], 0, api_gp(display,"x")-1, api_gp(display,"y")-3, 1, 1, 0, nil, 1)
	  end
	end
	
end

-------------------
--- SILKWORM FARM SCRIPTS ---
-------------------
function silkworm_farm_change(menu_id)
	-- if we have items in the first six slots let's get to work
  input_slots = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4, 5, 6}, false)
  api_sp(menu_id, "working", false)
  for k,input_slot in pairs(input_slots) do
	  if input_slot ~= nil and input_slot["stats"]["species"]=="silk_moth" then 
		api_sp(menu_id, "working", true)
		break
	  else
		api_sp(menu_id, "working", false)
		break
	  end
  end
end

function silkworm_farm_tick(menu_id)
  -- handle countdown if working
  if api_gp(menu_id, "working") == true then
    -- add to counter
    api_sp(menu_id, "p_start", api_gp(menu_id, "p_start") + 0.001)
    -- if we hit the end, i.e. 10s have passed
    if api_gp(menu_id, "p_start") >= api_gp(menu_id, "p_end") then

      -- reset the counter
      api_sp(menu_id, "p_start", 0)
      
      -- get the "input" slots to get an item
      input_slot = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4, 5, 6}, true)
      -- assuming there is a slot width stuff
      if input_slot ~= nil then
		api_log("worm "..input_slot["item"])
        -- remove 1 from slot
        api_slot_decr(input_slot["id"])

        -- add thread to output
        output_slot = api_slot_match_range(menu_id, {"", MOD_NAME.."_thread"}, {7, 8, 9, 10, 11, 12}, true)
        if output_slot ~= nil then
          -- if empty slot add 1 seed item
          if output_slot["item"] == "" then
            api_slot_set(output_slot["id"], MOD_NAME.."_thread", api_random_range(1,5))
          -- otherwise add to existing seed item in slot
          else 
            api_slot_incr(output_slot["id"],api_random_range(1,5))
          end
        end

        -- recheck input, if nothing then stop working
        input_slot = api_slot_match_range(menu_id, {"ANY"}, {1, 2, 3, 4, 5, 6}, true)
        if input_slot == nil then api_sp(menu_id, "working", false) end

      end
    end
  else
	api_sp(menu_id, "p_start", 0)
  end
end

function silkworm_farm_define(menu_id)

  -- create initial props
  api_dp(menu_id, "working", false)
  api_dp(menu_id, "p_start", 0)
  api_dp(menu_id, "p_end", 1)

  -- create gui for the menu
  api_define_gui(menu_id, "progress_bar", 56, 44, "silkworm_tooltip", "sprites/silkworm farm/silkworm_progress.png")
  
  -- save gui sprite ref for later
  spr = api_get_sprite("sp_"..MOD_NAME.."_silkworm_progress")
  api_dp(menu_id, "progress_bar_sprite", spr)

  -- add our p_start and p_end props to the default _fields list so the progress is saved 
  -- any keys in _fields will get their value saved when the game saves, and loaded when the game loads again
  fields = {"p_start", "p_end"}
  fields = api_sp(menu_id, "_fields", fields)

end

function silkworm_tooltip(menu_id)
  progress = math.floor((api_gp(menu_id, "p_start") / api_gp(menu_id, "p_end")) * 100)
  percent = tostring(progress) .. "%"
  return {
    {"Progress", "FONT_WHITE"},
    {percent, "FONT_BGREY"}
  }
end

function silkworm_farm_draw(menu_id)
  -- get camera
  cam = api_get_cam()

  -- draw gui progress here
  gui = api_get_inst(api_gp(menu_id, "progress_bar"))
  spr = api_gp(menu_id, "progress_bar_sprite")

  -- draw arrow "progress" block then cover up with arrow hole
  -- arrow sprite is 47x10
  gx = gui["x"] - cam["x"]
  gy = gui["y"] - cam["y"]
  progress = (api_gp(menu_id, "p_start") / api_gp(menu_id, "p_end") * 33)
  api_draw_sprite_part(spr, 0, 0, 0, progress, 9, gx, gy)
end

function silkworm_farm_object_draw(obj)
	highlighted = api_get_highlighted("menu_obj")
	-- api_log("highlighted ".. highlighted)
	-- api_log("this ".. obj)
	cur_frame = 0
	if (highlighted ~= nil) then
		if (highlighted == obj) then
			cur_frame = 1
		else
			cur_frame = 0
		end
	else
		cur_frame = 0
	end
	
	if (api_gp(api_gp(obj, "menu"), "working") == true) then
		if (cur_frame == 1) then
			api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_silkworm_full"), cur_frame, api_gp(obj,"x"), api_gp(obj,"y"), 1, 1, 0, nil, 1)
			api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_highlight_arrow"), 0, api_gp(obj,"x")+4, api_gp(obj,"y")-7, 1, 1, 0, nil, 1)
		end
		api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_silkworm_full"), cur_frame, api_gp(obj,"x"), api_gp(obj,"y"), 1, 1, 0, nil, 1)
	else
		if (cur_frame == 1) then
			api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_silkworm_empty"), cur_frame, api_gp(obj,"x"), api_gp(obj,"y"), 1, 1, 0, nil, 1)
			api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_highlight_arrow"), 0, api_gp(obj,"x")+4, api_gp(obj,"y")-7, 1, 1, 0, nil, 1)
		end
		api_draw_sprite_ext(api_get_sprite("sp_"..MOD_NAME.."_silkworm_empty"), cur_frame, api_gp(obj,"x"), api_gp(obj,"y"), 1, 1, 0, nil, 1)
	end
end
-------------------
--- BEE SCRIPTS ---
-------------------

-- define the mutation critera/chance for our new bee
function mutation_chance()
  -- rocky-dream 30% chance at night to mutate
  if (bee_a == "rocky" and bee_b == "dream") or (bee_a == "dream" and bee_b == "rocky") then
    time = api_get_time()
    chance = api_random(99) + 1
    if time["name"] == "Night" and chance <= 30 then
      return true
    end
  end
  return false;
end

-------------------
--- CLOTHING SPRITES ---
-------------------

function init_clothing_table()
	CLOTHING_TABLE["lily_mod_purple_dress"] = {}
	CLOTHING_TABLE["lily_mod_purple_dress"][0] = api_define_sprite("purple_dress_stand","sprites/clothes/dress0/clothes_standing.png",2)
	CLOTHING_TABLE["lily_mod_purple_dress"][1] = api_define_sprite("purple_dress_walk","sprites/clothes/dress0/clothes_walking.png",4)
	CLOTHING_TABLE["lily_mod_purple_dress"][2] = api_define_sprite("purple_dress_stand_h","sprites/clothes/dress0/clothes_standing_h.png",2)
	CLOTHING_TABLE["lily_mod_purple_dress"][3] = api_define_sprite("purple_dress_walk_h","sprites/clothes/dress0/clothes_walking_h.png",4)
	
	CLOTHING_TABLE["lily_mod_purple_bow"] = {}
	CLOTHING_TABLE["lily_mod_purple_bow"][0] = api_define_sprite("purple_bow_stand","sprites/clothes/bow0/clothes_standing.png",2)
	CLOTHING_TABLE["lily_mod_purple_bow"][1] = api_define_sprite("purple_bow_walk","sprites/clothes/bow0/clothes_walking.png",4)
	CLOTHING_TABLE["lily_mod_purple_bow"][2] = api_define_sprite("purple_bow_stand_h","sprites/clothes/bow0/clothes_standing_h.png",2)
	CLOTHING_TABLE["lily_mod_purple_bow"][3] = api_define_sprite("purple_bow_walk_h","sprites/clothes/bow0/clothes_walking_h.png",4)
	
	CLOTHING_TABLE["lily_mod_bunny_ears"] = {}
	CLOTHING_TABLE["lily_mod_bunny_ears"][0] = api_define_sprite("bunny_ears_stand","sprites/clothes/bunny_ears/clothes_standing.png",2)
	CLOTHING_TABLE["lily_mod_bunny_ears"][1] = api_define_sprite("bunny_ears_walk","sprites/clothes/bunny_ears/clothes_walking.png",4)
	CLOTHING_TABLE["lily_mod_bunny_ears"][2] = api_define_sprite("bunny_ears_stand_h","sprites/clothes/bunny_ears/clothes_standing_h.png",2)
	CLOTHING_TABLE["lily_mod_bunny_ears"][3] = api_define_sprite("bunny_ears_walk_h","sprites/clothes/bunny_ears/clothes_walking_h.png",4)
	
end